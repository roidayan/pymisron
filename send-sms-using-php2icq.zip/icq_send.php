<html>
<body>
<?php

include 'php2icq.php';
if (array_key_exists ("target",$_POST)&& array_key_exists ("message",$_POST))
{
    $icq = new php2icq('12345678', 'xxxx', STATUS_ONLINE);
    if (!$icq->login())
    {
        echo $icq->get_error();
    } else {
        //$icq->send_message('213121585', 'hi my first php2icq message :)');\
        //$icq->send_sms_message("+972547777777", '(Regressor,  ICQ):..Just test SMS message (......)', 'Regressor');
        //$icq->send_sms_message("+972547777777", 'hi', 'test');
        //$icq->send_sms_message($_POST["target"], '(Web,  ICQ):'.$_POST["message"], 'Web');
	$icq->send_sms_message($_POST["target"], $_POST["message"], 'Web');
        echo ("sending message"."<br/>");
    }
}
//DumpBlock ("this is a nice test\r\n to check this binary dump");

?>
<form method="post" action="icq_send.php">
<table>
<tr><td>Target</td><td><input type=text value="+972" name="target"></td></tr>
<tr><td>Message</td><td><input type=text value="" name="message"></td></tr>
<tr><td colspan=2><input type=submit></td></tr>
</table>
</body>
</html>
